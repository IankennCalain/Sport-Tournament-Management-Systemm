const app = document.getElementById("app");
const toast = document.createElement("div");
toast.className = "toast";
document.body.appendChild(toast);

let page = "dashboard";
const teams = [
  ["PE","Pasig Eagles",5,1,15],["MH","Makati Hawks",4,2,12],
  ["RT","Rizal Tigers",4,2,12],["MK","Manila Kings",3,3,9],
  ["QC","Quezon City Warriors",3,3,9],["TT","Taguig Titans",2,4,6]
];

const navItems = [
  ["dashboard","Dashboard"],["teams","Teams"],["tournaments","Tournaments"],
  ["matches","Matches"],["standings","Standings"],["players","Players"],
  ["schedule","Schedule"],["reports","Reports"]
];

function showToast(message){
  toast.textContent=message; toast.style.display="block";
  clearTimeout(window.toastTimer);
  window.toastTimer=setTimeout(()=>toast.style.display="none",1800);
}
function go(p){page=p; render()}

function shell(content){
  return `<div class="app">
    <aside class="sidebar">
      <div class="brand">🏆 Sports Tournament<br>Management System</div>
      ${navItems.map(([id,label])=>`<button class="nav ${page===id?'active':''}" onclick="go('${id}')">${label}</button>`).join("")}
      <button class="nav logout" onclick="go('login')">↪ Logout</button>
    </aside>
    <main class="main">${content}</main>
  </div>`;
}
function header(title,sub,button=""){
  return `<div class="topbar"><div><h1>${title}</h1><div class="subtitle">${sub}</div></div>${button}</div>`;
}

function dashboard(){
 return header("Dashboard","Tournament overview and recent activity",`<button class="btn" onclick="go('addTournament')">+ Create Tournament</button>`) +
 `<div class="cards">
  ${[["Total Teams","12"],["Total Players","96"],["Total Matches","24"],["Active Tournaments","3"]].map(x=>`<div class="card"><div class="stat-label">${x[0]}</div><div class="stat">${x[1]}</div></div>`).join("")}
 </div>
 <div class="grid2">
  <div class="card"><h3>Recent Matches</h3><div class="table-wrap"><table class="table">
   <tr><th>Match</th><th>Score</th><th>Status</th></tr>
   <tr><td>Pasig Eagles vs Makati Hawks</td><td>78–65</td><td><span class="badge success">Finished</span></td></tr>
   <tr><td>Rizal Tigers vs Manila Kings</td><td>72–68</td><td><span class="badge success">Finished</span></td></tr>
   <tr><td>QC Warriors vs San Juan Skyriders</td><td>60–58</td><td><span class="badge success">Finished</span></td></tr>
  </table></div></div>
  <div class="card"><h3>Upcoming Matches</h3><div class="list">
   <div class="row"><span>Makati Hawks vs Marikina Legends</span><b>10:00 AM</b></div>
   <div class="row"><span>QC Warriors vs San Juan Skyriders</span><b>1:00 PM</b></div>
   <div class="row"><span>Taguig Titans vs Rizal Tigers</span><b>4:00 PM</b></div>
  </div></div>
 </div>`;
}

function teamsPage(){
 return header("Teams","Manage participating teams",`<button class="btn" onclick="go('addTeam')">+ Add Team</button>`) +
 `<div class="team-grid">${teams.map(t=>`<div class="card team-card" onclick="teamDetail('${t[1]}')"><div class="logo">${t[0]}</div><b>${t[1]}</b><div class="subtitle">Wins: ${t[2]} · Losses: ${t[3]} · Points: ${t[4]}</div></div>`).join("")}</div>`;
}
function teamDetail(name){
 const t=teams.find(x=>x[1]===name)||teams[0];
 app.innerHTML=shell(header(name,"Team profile and performance",`<button class="btn secondary" onclick="go('teams')">← Back</button>`)+
 `<div class="grid2"><div class="card"><div class="logo">${t[0]}</div><h2>${t[1]}</h2><p class="subtitle">Coach / Manager: Sample Coach</p><div class="cards" style="grid-template-columns:repeat(3,1fr)"><div><b>${t[2]}</b><div class="stat-label">Wins</div></div><div><b>${t[3]}</b><div class="stat-label">Losses</div></div><div><b>${t[4]}</b><div class="stat-label">Points</div></div></div></div>
 <div class="card"><h3>Team Actions</h3><div class="actions"><button class="btn" onclick="showToast('Edit team opened')">Edit Team</button><button class="btn secondary" onclick="go('players')">View Players</button></div></div></div>`);
}

function addTeam(){
 return header("Add Team","Register a new tournament team",`<button class="btn secondary" onclick="go('teams')">← Back</button>`)+
 `<form class="form card" onsubmit="event.preventDefault();showToast('Team saved successfully');go('teams')">
  <div class="field"><label>Team Name</label><input required placeholder="e.g. Pasig Warriors"></div>
  <div class="field"><label>Coach / Manager</label><input required placeholder="Enter coach name"></div>
  <div class="field"><label>Sport</label><select><option>Basketball</option><option>Volleyball</option><option>Football</option></select></div>
  <div class="actions"><button class="btn">Save Team</button><button type="button" class="btn secondary" onclick="go('teams')">Cancel</button></div>
 </form>`;
}

function tournaments(){
 return header("Tournaments","Create and monitor competitions",`<button class="btn" onclick="go('addTournament')">+ Create Tournament</button>`)+
 `<div class="list">
  <div class="card row"><div><b>Inter-Barangay Basketball Cup</b><div class="subtitle">16 teams · Oct 5–15, 2026</div></div><span class="badge success">Ongoing</span></div>
  <div class="card row"><div><b>Volleyball Friendship League</b><div class="subtitle">8 teams · Nov 1–10, 2026</div></div><span class="badge warn">Upcoming</span></div>
  <div class="card row"><div><b>City Sports Fest</b><div class="subtitle">12 teams · Dec 1–20, 2026</div></div><span class="badge warn">Upcoming</span></div>
 </div>`;
}
function addTournament(){
 return header("Create Tournament","Set up a new competition",`<button class="btn secondary" onclick="go('tournaments')">← Back</button>`)+
 `<form class="form card" onsubmit="event.preventDefault();showToast('Tournament created successfully');go('tournaments')">
  <div class="field"><label>Tournament Name</label><input required placeholder="Tournament name"></div>
  <div class="field"><label>Sport</label><select><option>Basketball</option><option>Volleyball</option><option>Football</option></select></div>
  <div class="field"><label>Number of Teams</label><input required type="number" min="2" max="64" value="8"></div>
  <div class="actions"><button class="btn">Create Tournament</button><button type="button" class="btn secondary" onclick="go('tournaments')">Cancel</button></div>
 </form>`;
}

function matches(){
 return header("Match Schedule","Upcoming and completed games",`<button class="btn" onclick="go('matchDetails')">View Sample Match</button>`)+
 `<div class="card"><div class="table-wrap"><table class="table"><tr><th>Time</th><th>Home</th><th>Away</th><th>Status</th><th>Action</th></tr>
 <tr><td>10:00 AM</td><td>Makati Hawks</td><td>Marikina Legends</td><td><span class="badge">Upcoming</span></td><td><button class="btn secondary" onclick="go('matchDetails')">View</button></td></tr>
 <tr><td>1:00 PM</td><td>QC Warriors</td><td>San Juan Skyriders</td><td><span class="badge">Upcoming</span></td><td><button class="btn secondary" onclick="go('matchDetails')">View</button></td></tr>
 <tr><td>4:00 PM</td><td>Taguig Titans</td><td>Rizal Tigers</td><td><span class="badge">Upcoming</span></td><td><button class="btn secondary" onclick="go('matchDetails')">View</button></td></tr>
 <tr><td>7:00 PM</td><td>Pasig Eagles</td><td>Manila Kings</td><td><span class="badge">Upcoming</span></td><td><button class="btn secondary" onclick="go('matchDetails')">View</button></td></tr>
 </table></div></div>`;
}
function matchDetails(){
 return header("Match Details","Pasig Eagles vs Makati Hawks",`<button class="btn secondary" onclick="go('matches')">← Back</button>`)+
 `<div class="card"><div class="score"><div><div class="score-team">Pasig Eagles</div><div class="score-num">78</div></div><div><span class="badge success">FINISHED</span><div class="subtitle">Oct 8, 2026 · 3:00 PM</div></div><div><div class="score-team">Makati Hawks</div><div class="score-num">65</div></div></div></div>
 <div class="card" style="margin-top:16px"><h3>Quarter Scores</h3><div class="table-wrap"><table class="table"><tr><th>Team</th><th>Q1</th><th>Q2</th><th>Q3</th><th>Q4</th><th>Total</th></tr><tr><td>Pasig Eagles</td><td>20</td><td>18</td><td>22</td><td>18</td><td><b>78</b></td></tr><tr><td>Makati Hawks</td><td>15</td><td>17</td><td>14</td><td>19</td><td><b>65</b></td></tr></table></div>
 <div class="actions"><button class="btn" onclick="showToast('Score editor opened')">Update Score</button><button class="btn secondary" onclick="showToast('Teams notified')">Notify Teams</button></div></div>`;
}
function standings(){
 return header("Tournament Standings","Current rankings and points")+`<div class="card"><div class="table-wrap"><table class="table"><tr><th>#</th><th>Team</th><th>W</th><th>L</th><th>Pts</th><th>Diff</th></tr>${teams.map((t,i)=>`<tr><td><b>${i+1}</b></td><td>${t[1]}</td><td>${t[2]}</td><td>${t[3]}</td><td>${t[4]}</td><td>+${42-i*7}</td></tr>`).join("")}</table></div></div>`;
}
function players(){
 return header("Players","Manage player profiles and statistics",`<button class="btn" onclick="showToast('Player form opened')">+ Add Player</button>`)+
 `<div class="card"><div class="table-wrap"><table class="table"><tr><th>Name</th><th>Team</th><th>Position</th><th>Status</th></tr>
 <tr><td>Juan Dela Cruz</td><td>Pasig Eagles</td><td>Guard</td><td><span class="badge success">Active</span></td></tr>
 <tr><td>Miguel Santos</td><td>Makati Hawks</td><td>Forward</td><td><span class="badge success">Active</span></td></tr>
 <tr><td>Carlo Reyes</td><td>Rizal Tigers</td><td>Center</td><td><span class="badge success">Active</span></td></tr>
 <tr><td>Daniel Ramos</td><td>Manila Kings</td><td>Guard</td><td><span class="badge success">Active</span></td></tr>
 </table></div></div>`;
}
function schedule(){
 const days=Array.from({length:31},(_,i)=>i+1);
 return header("Schedule","Calendar of tournament activities")+`<div class="grid2"><div class="card"><h3>October 2026</h3><div class="calendar">${["S","M","T","W","T","F","S"].map(x=>`<div class="day"><b>${x}</b></div>`).join("")}${days.map(d=>`<div class="day ${[5,8,10,15].includes(d)?'event':''}">${d}</div>`).join("")}</div></div>
 <div class="card"><h3>Upcoming Events</h3><div class="list"><div class="row"><span>Oct 5<br><b>Tournament Opening</b></span></div><div class="row"><span>Oct 8<br><b>Pasig Eagles vs Makati Hawks</b></span></div><div class="row"><span>Oct 15<br><b>Finals</b></span></div></div></div></div>`;
}
function reports(){
 return header("Reports","Generate tournament and performance reports")+`<div class="grid3">
 ${[["Tournament Report","Teams, matches, results and standings."],["Team Report","Performance and rankings."],["Player Report","Individual statistics."],["Match Report","Match results and summary."]].map(x=>`<div class="card"><h3>${x[0]}</h3><p class="subtitle">${x[1]}</p><button class="btn" onclick="showToast('Report generated successfully')">Generate</button></div>`).join("")}
 </div>`;
}
function login(){
 return `<div class="login-page"><div class="login-card"><div class="logo">🏆</div><h1>Sports Tournament Management System</h1><div class="subtitle">Organize · Manage · Track · Compete</div>
 <form class="form" onsubmit="event.preventDefault();go('dashboard');showToast('Login successful')">
 <div class="field"><label>Username or Email</label><input required placeholder="Enter username"></div>
 <div class="field"><label>Password</label><input required type="password" placeholder="Enter password"></div>
 <button class="btn">Login</button></form></div></div>`;
}
function render(){
 if(page==="login"){app.innerHTML=login();return}
 const pages={dashboard,teams:teamsPage,tournaments,matches,matchDetails,standings,players,schedule,reports,addTeam,addTournament};
 app.innerHTML=shell(pages[page]());
}
render();
