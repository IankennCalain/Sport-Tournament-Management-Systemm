# Sports Tournament Management System

A student-friendly front-end prototype for Topic #23: Sports Tournament Management System.

## Features
- Login screen
- Dashboard
- Team management
- Tournament management
- Match schedule
- Match details and scores
- Tournament standings and rankings
- Player management
- Calendar schedule
- Reports
- Responsive/mobile layout
- Interactive navigation and forms
- Toast notifications

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser.

No server or database is required for this prototype.

## Suggested Figma mapping
Use the same screens as frames:
Login → Dashboard → Teams → Team Details → Add Team → Tournaments → Add Tournament → Matches → Match Details → Standings → Players → Schedule → Reports.

## GitHub Pages
After uploading the three files and README to a GitHub repository:
1. Open repository Settings.
2. Open Pages.
3. Select the main branch and root folder.
4. Save.
5. GitHub will provide the published website URL.
